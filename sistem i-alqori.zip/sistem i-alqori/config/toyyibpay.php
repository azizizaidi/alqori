<?php

return[
    'key'      => env('TOYYIBPAY_USER_SECRET_KEY'),
    'category' => env('TOYYIBPAY_CATEGORY_CODE'),
];