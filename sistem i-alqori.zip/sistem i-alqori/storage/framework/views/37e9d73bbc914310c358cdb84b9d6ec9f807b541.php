<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.student.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.students.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="student_id"><?php echo e(trans('cruds.student.fields.student')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('student') ? 'is-invalid' : ''); ?>" name="student_id" id="student_id" required>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('student_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('student')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('student')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.student.fields.student_helper')); ?></span>
            </div>

            <div class="form-group">
                <label class="required" for="registrar_id"><?php echo e(trans('cruds.student.fields.registrar')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('registrar') ? 'is-invalid' : ''); ?>" name="registrar_id" id="registrar_id" required>
              
                <?php $__currentLoopData = $registrars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $registrar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($id); ?>" ><?php echo e($registrar); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('registrar')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('registrar')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.student.fields.registrar_helper')); ?></span>
            </div>
        
            <div class="form-group">
                <label class="required" for="code"><?php echo e(trans('cruds.student.fields.code')); ?></label>
                <input class="form-control <?php echo e($errors->has('code') ? 'is-invalid' : ''); ?>" type="text" name="code" id="code" value="<?php echo e(old('code', '')); ?>" required>
                <?php if($errors->has('code')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('code')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.student.fields.code_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="age_stage"><?php echo e(trans('cruds.student.fields.age_stage')); ?></label>
                <input class="form-control <?php echo e($errors->has('age_stage') ? 'is-invalid' : ''); ?>" type="text" name="age_stage" id="age_stage" value="<?php echo e(old('age_stage', '')); ?>" required>
                <?php if($errors->has('age_stage')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('age_stage')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.student.fields.age_stage_helper')); ?></span>
            </div>
            <div class="form-group">
                <label  for="notes"><?php echo e(trans('cruds.student.fields.notes')); ?></label>
             <textarea class="form-control <?php echo e($errors->has('note') ? 'is-invalid' : ''); ?>"  name="note" id="note" value="<?php echo e(old('note', '')); ?>" required>
                <?php if($errors->has('note')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('note')); ?>

                    </div>
                <?php endif; ?>
                 </textarea>
                 <span class="help-block"><?php echo e(trans('cruds.student.fields.age_stage_helper')); ?></span>
         
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/azizizaidi/test/resources/views/admin/students/create.blade.php ENDPATH**/ ?>