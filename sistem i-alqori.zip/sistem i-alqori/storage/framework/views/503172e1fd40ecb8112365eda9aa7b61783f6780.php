<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.assignClassTeacher.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.assign-class-teachers.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="teacher_id"><?php echo e(trans('cruds.assignClassTeacher.fields.teacher')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('teacher') ? 'is-invalid' : ''); ?>" name="teacher_id" id="teacher_id" required>
                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('teacher_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('teacher')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('teacher')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.assignClassTeacher.fields.teacher_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="teacher_code"><?php echo e(trans('cruds.assignClassTeacher.fields.teacher_code')); ?></label>
                <input class="form-control <?php echo e($errors->has('teacher_code') ? 'is-invalid' : ''); ?>" type="text" name="teacher_code" id="teacher_code" value="<?php echo e(old('teacher_code', '')); ?>" required>
                <?php if($errors->has('teacher_code')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('teacher_code')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.assignClassTeacher.fields.teacher_code_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="student_id"><?php echo e(trans('cruds.assignClassTeacher.fields.student')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('student') ? 'is-invalid' : ''); ?>" name="student_id" id="student_id" required>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('student_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('student')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('student')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.assignClassTeacher.fields.student_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="student_code"><?php echo e(trans('cruds.assignClassTeacher.fields.student_code')); ?></label>
                <input class="form-control <?php echo e($errors->has('student_code') ? 'is-invalid' : ''); ?>" type="text" name="student_code" id="student_code" value="<?php echo e(old('student_code', '')); ?>" required>
                <?php if($errors->has('student_code')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('student_code')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.assignClassTeacher.fields.student_code_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="class_id"><?php echo e(trans('cruds.assignClassTeacher.fields.class')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('class') ? 'is-invalid' : ''); ?>" name="class_id" id="class_id" required>
                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('class_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('class')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('class')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.assignClassTeacher.fields.class_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/azizizaidi/apps_2/resources/views/admin/assignClassTeachers/create.blade.php ENDPATH**/ ?>