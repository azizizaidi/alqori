<div id="sidebar" class="c-sidebar c-sidebar-fixed c-sidebar-lg-show">

    <div class="c-sidebar-brand d-md-down-none">
        <a class="c-sidebar-brand-full h4" href="#">
            <?php echo e(trans('panel.site_title')); ?>

        </a>
    </div>

    <ul class="c-sidebar-nav">
        <li class="c-sidebar-nav-item">
            <a href="<?php echo e(route("admin.home")); ?>" class="c-sidebar-nav-link">
                <i class="c-sidebar-nav-icon fas fa-fw fa-tachometer-alt">

                </i>
                <?php echo e(trans('global.dashboard')); ?>

            </a>
        </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/permissions*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/roles*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/users*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/audit-logs*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-users c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.userManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.permissions.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/permissions") || request()->is("admin/permissions/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-unlock-alt c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.permission.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.roles.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/roles") || request()->is("admin/roles/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-briefcase c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.role.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.users.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/users") || request()->is("admin/users/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-user c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.user.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('audit_log_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.audit-logs.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/audit-logs") || request()->is("admin/audit-logs/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-file-alt c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.auditLog.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('teacher_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/teachers*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-cogs c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.teacherManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('teacher_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.teachers.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/teachers") || request()->is("admin/teachers/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-chalkboard-teacher c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.teacher.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('class_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/class-types*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/class-names*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/class-packages*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/class-numbers*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/register-classes*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/assign-class-teachers*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-bezier-curve c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.classManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('class_type_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.class-types.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/class-types") || request()->is("admin/class-types/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-receipt c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.classType.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('class_name_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.class-names.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/class-names") || request()->is("admin/class-names/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-tags c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.className.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('class_package_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.class-packages.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/class-packages") || request()->is("admin/class-packages/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-folder-open c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.classPackage.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('class_number_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.class-numbers.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/class-numbers") || request()->is("admin/class-numbers/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-list-ol c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.classNumber.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('register_class_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.register-classes.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/register-classes") || request()->is("admin/register-classes/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-coins c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.registerClass.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assign_class_teacher_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.assign-class-teachers.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/assign-class-teachers") || request()->is("admin/assign-class-teachers/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw far fa-window-restore c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.assignClassTeacher.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('regist_student_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/students*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/registrars*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/stdnt-rgstrs*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-cogs c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.registStudentManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('student_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.students.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/students") || request()->is("admin/students/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-user-graduate c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.student.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('registrar_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.registrars.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/registrars") || request()->is("admin/registrars/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-user-shield c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.registrar.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stdnt_rgstr_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.stdnt-rgstrs.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/stdnt-rgstrs") || request()->is("admin/stdnt-rgstrs/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-user-friends c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.stdntRgstr.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_alert_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.user-alerts.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/user-alerts") || request()->is("admin/user-alerts/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-bell c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.userAlert.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/task-statuses*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/task-tags*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/tasks*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/tasks-calendars*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-list c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.taskManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task_status_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.task-statuses.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/task-statuses") || request()->is("admin/task-statuses/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-server c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.taskStatus.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task_tag_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.task-tags.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/task-tags") || request()->is("admin/task-tags/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-server c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.taskTag.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.tasks.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/tasks") || request()->is("admin/tasks/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-briefcase c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.task.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tasks_calendar_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.tasks-calendars.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/tasks-calendars") || request()->is("admin/tasks-calendars/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-calendar c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.tasksCalendar.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expense_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/expense-categories*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/income-categories*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/expenses*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/incomes*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/expense-reports*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-money-bill c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.expenseManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expense_category_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.expense-categories.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/expense-categories") || request()->is("admin/expense-categories/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-list c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.expenseCategory.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('income_category_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.income-categories.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/income-categories") || request()->is("admin/income-categories/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-list c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.incomeCategory.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expense_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.expenses.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/expenses") || request()->is("admin/expenses/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-arrow-circle-right c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.expense.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('income_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.incomes.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/incomes") || request()->is("admin/incomes/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-arrow-circle-right c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.income.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expense_report_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.expense-reports.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/expense-reports") || request()->is("admin/expense-reports/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-chart-line c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.expenseReport.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fee_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/fees*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/invoices*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-cogs c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.feeManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fee_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.fees.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/fees") || request()->is("admin/fees/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-money-bill-alt c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.fee.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.invoices.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/invoices") || request()->is("admin/invoices/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-tasks c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.invoice.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('report_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/report-classes*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-cogs c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.reportManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('report_class_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.report-classes.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/report-classes") || request()->is("admin/report-classes/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-edit c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.reportClass.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('report_class_student')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.report-classes.index-student")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/report-classes/index-student") || request()->is("admin/report-classes/index-student") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-edit c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.invoiceStudent.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php ($unread = \App\Models\QaTopic::unreadCount()); ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.messenger.index")); ?>" class="<?php echo e(request()->is("admin/messenger") || request()->is("admin/messenger/*") ? "c-active" : ""); ?> c-sidebar-nav-link">
                    <i class="c-sidebar-nav-icon fa-fw fa fa-envelope">

                    </i>
                    <span><?php echo e(trans('global.messages')); ?></span>
                    <?php if($unread > 0): ?>
                        <strong>( <?php echo e($unread); ?> )</strong>
                    <?php endif; ?>

                </a>
            </li>
            <?php if(file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile_password_edit')): ?>
                    <li class="c-sidebar-nav-item">
                        <a class="c-sidebar-nav-link <?php echo e(request()->is('profile/password') || request()->is('profile/password/*') ? 'c-active' : ''); ?>" href="<?php echo e(route('profile.password.edit')); ?>">
                            <i class="fa-fw fas fa-key c-sidebar-nav-icon">
                            </i>
                            <?php echo e(trans('global.change_password')); ?>

                        </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
            <li class="c-sidebar-nav-item">
                <a href="#" class="c-sidebar-nav-link" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                    <i class="c-sidebar-nav-icon fas fa-fw fa-sign-out-alt">

                    </i>
                    <?php echo e(trans('global.logout')); ?>

                </a>
            </li>
    </ul>

</div><?php /**PATH C:\laragon\www\school11\resources\views/partials/menu.blade.php ENDPATH**/ ?>