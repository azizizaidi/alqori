<?php $__env->startSection('title', __('Maintenance Mode')); ?>
<?php $__env->startSection('code', '503'); ?>
<?php $__env->startSection('message', __('Maintenance Mode')); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u829014500/domains/alqori.com/public_html/apps_2/vendor/laravel/framework/src/Illuminate/Foundation/Exceptions/views/503.blade.php ENDPATH**/ ?>