<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.registrar.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.registrars.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="code"><?php echo e(trans('cruds.registrar.fields.code')); ?></label>
                <input class="form-control <?php echo e($errors->has('code') ? 'is-invalid' : ''); ?>" type="text" name="code" id="code" value="<?php echo e(old('code', '')); ?>" required>
                <?php if($errors->has('code')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('code')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.registrar.fields.code_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="phone"><?php echo e(trans('cruds.registrar.fields.phone')); ?></label>
                <input class="form-control <?php echo e($errors->has('phone') ? 'is-invalid' : ''); ?>" type="text" name="phone" id="phone" value="<?php echo e(old('phone', '')); ?>" required>
                <?php if($errors->has('phone')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('phone')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.registrar.fields.phone_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="address"><?php echo e(trans('cruds.registrar.fields.address')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('address') ? 'is-invalid' : ''); ?>" name="address" id="address"><?php echo e(old('address')); ?></textarea>
                <?php if($errors->has('address')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('address')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.registrar.fields.address_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="registrar_id"><?php echo e(trans('cruds.registrar.fields.registrar')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('registrar') ? 'is-invalid' : ''); ?>" name="registrar_id" id="registrar_id" required>
                    <?php $__currentLoopData = $registrars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('registrar_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('registrar')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('registrar')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.registrar.fields.registrar_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/azizizaidi/test/resources/views/admin/registrars/create.blade.php ENDPATH**/ ?>