<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.teacher.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.teachers.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="teacher_id"><?php echo e(trans('cruds.teacher.fields.teacher')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('teacher') ? 'is-invalid' : ''); ?>" name="teacher_id" id="teacher_id" required>
                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('teacher_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('teacher')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('teacher')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.teacher.fields.teacher_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="code"><?php echo e(trans('cruds.teacher.fields.code')); ?></label>
                <input class="form-control <?php echo e($errors->has('code') ? 'is-invalid' : ''); ?>" type="text" name="code" id="code" value="<?php echo e(old('code', '')); ?>" required>
                <?php if($errors->has('code')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('code')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.teacher.fields.code_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="phone"><?php echo e(trans('cruds.teacher.fields.phone')); ?></label>
                <input class="form-control <?php echo e($errors->has('phone') ? 'is-invalid' : ''); ?>" type="number" name="phone" id="phone" value="<?php echo e(old('phone', '')); ?>" step="1" required>
                <?php if($errors->has('phone')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('phone')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.teacher.fields.phone_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="address"><?php echo e(trans('cruds.teacher.fields.address')); ?></label>
                <input class="form-control <?php echo e($errors->has('address') ? 'is-invalid' : ''); ?>" type="text" name="address" id="address" value="<?php echo e(old('address', '')); ?>" required>
                <?php if($errors->has('address')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('address')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.teacher.fields.address_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="position"><?php echo e(trans('cruds.teacher.fields.position')); ?></label>
                <input class="form-control <?php echo e($errors->has('position') ? 'is-invalid' : ''); ?>" type="text" name="position" id="position" value="<?php echo e(old('position', '')); ?>" required>
                <?php if($errors->has('position')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('position')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.teacher.fields.position_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="sex"><?php echo e(trans('cruds.teacher.fields.sex')); ?></label>
                <input class="form-control <?php echo e($errors->has('sex') ? 'is-invalid' : ''); ?>" type="text" name="sex" id="sex" value="<?php echo e(old('sex', '')); ?>" required>
                <?php if($errors->has('sex')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('sex')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.teacher.fields.sex_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="resume"><?php echo e(trans('cruds.teacher.fields.resume')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('resume') ? 'is-invalid' : ''); ?>" id="resume-dropzone">
                </div>
                <?php if($errors->has('resume')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('resume')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.teacher.fields.resume_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="bank_name"><?php echo e(trans('cruds.teacher.fields.bank_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('bank_name') ? 'is-invalid' : ''); ?>" type="text" name="bank_name" id="bank_name" value="<?php echo e(old('bank_name', '')); ?>">
                <?php if($errors->has('bank_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('bank_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.teacher.fields.bank_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="account_bank"><?php echo e(trans('cruds.teacher.fields.account_bank')); ?></label>
                <input class="form-control <?php echo e($errors->has('account_bank') ? 'is-invalid' : ''); ?>" type="number" name="account_bank" id="account_bank" value="<?php echo e(old('account_bank', '')); ?>" step="1">
                <?php if($errors->has('account_bank')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('account_bank')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.teacher.fields.account_bank_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    Dropzone.options.resumeDropzone = {
    url: '<?php echo e(route('admin.teachers.storeMedia')); ?>',
    maxFilesize: 4, // MB
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 4
    },
    success: function (file, response) {
      $('form').find('input[name="resume"]').remove()
      $('form').append('<input type="hidden" name="resume" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="resume"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($teacher) && $teacher->resume): ?>
      var file = <?php echo json_encode($teacher->resume); ?>

          this.options.addedfile.call(this, file)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="resume" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\school11\resources\views/admin/teachers/create.blade.php ENDPATH**/ ?>