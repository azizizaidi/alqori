<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.stdntRgstr.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.stdnt-rgstrs.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="registrar_id"><?php echo e(trans('cruds.stdntRgstr.fields.registrar')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('registrar') ? 'is-invalid' : ''); ?>" name="registrar_id" id="registrar_id" required>
                    <?php $__currentLoopData = $registrars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('registrar_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('registrar')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('registrar')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.stdntRgstr.fields.registrar_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="student_id"><?php echo e(trans('cruds.stdntRgstr.fields.student')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('student') ? 'is-invalid' : ''); ?>" name="student_id" id="student_id" required>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('student_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('student')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('student')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.stdntRgstr.fields.student_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u829014500/domains/i-alqori.com/public_html/resources/views/admin/stdntRgstrs/create.blade.php ENDPATH**/ ?>