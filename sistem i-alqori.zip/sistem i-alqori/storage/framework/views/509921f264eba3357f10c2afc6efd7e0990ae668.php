<?php $__env->startSection('title', __('test.detail')); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header"><?php echo e(__('test.detail')); ?></div>
            <div class="card-body">
                <table class="table table-sm">
                    <tbody>
                        <tr><td><?php echo e(__('test.name')); ?></td><td><?php echo e($test->name); ?></td></tr>
                        <tr><td><?php echo e(__('test.description')); ?></td><td><?php echo e($test->description); ?></td></tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $test)): ?>
                    <a href="<?php echo e(route('tests.edit', $test)); ?>" id="edit-test-<?php echo e($test->id); ?>" class="btn btn-warning"><?php echo e(__('test.edit')); ?></a>
                <?php endif; ?>
                <a href="<?php echo e(route('tests.index')); ?>" class="btn btn-link"><?php echo e(__('test.back_to_index')); ?></a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\school11\resources\views/tests/show.blade.php ENDPATH**/ ?>