<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="row">
        <div class="col-lg-12">
             <div class="card">
                <div class="card-header">
                    Dashboard
                </div>


                <!----1st col---->
                
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(Auth::user()->roles->contains(1)): ?>
                    <div class="row">
                      <div class="col-lg-4">
                   <div class="card text-white bg-primary " style="width: 18rem;">
                       <div class="card-body">
                      
                           <h5 class="card-title"><?php echo e($registrars->count('id') ?? ''); ?></h5>
                      
                             <p class="card-text">Total Registrars</p>
                           
                         </div>
                    
                     </div>
                     </div>
                     <!----------2nd col------->
                     <div class="col-lg-4">
                     <div class="card text-white bg-warning " style="width: 18rem;">
                       <div class="card-body">
                           <h5 class="card-title"><?php echo e($teachers->count('id') ?? ''); ?></h5>
                             <p class="card-text">Total Teachers</p>
                           
                         </div>
                    
                     </div>
                     </div>
                      <!----------3rd col------->
                      <div class="col-lg-4">
                      <div class="card text-white bg-success " style="width: 18rem;">
                       <div class="card-body">
                           <h5 class="card-title"><?php echo e($students->count('id') ?? ''); ?></h5>
                             <p class="card-text">Total Students</p>
                           
                         </div>
                    
                     </div>
                     </div>
                     </div>
                   <!----end col---->
                      <div class="row">
                      <div class="col-lg-4">
                   <div class="card text-white bg-info " style="width: 18rem;">
                       <div class="card-body">
                      
                           <h5 class="card-title">RM<?php echo e($reportclasses->sum('fee_student') ?? ''); ?></h5>
                      
                             <p class="card-text">Total Sales</p>
                           
                         </div>
                    
                     </div>
                     </div>
                     <!--------------------->
                        <div class="col-lg-4">
                   <div class="card text-white  " style="width: 18rem; background-color:Violet;">
                       <div class="card-body">
                      
                           <h5 class="card-title">RM<?php echo e($reportclasses->sum('allowance') ?? ''); ?></h5>
                      
                             <p class="card-text">Total Allowance</p>
                           
                         </div>
                    
                     </div>
                     </div>
                     </div>
                     <?php elseif(Auth::user()->roles->contains(2)): ?>
                   <div class="card">
    <div class="card-header">
        <?php echo e("List Class"); ?> 
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table id="dtBasicExample "class=" table table-bordered table-striped table-hover datatable datatable-allowance ">
                <thead>
                    <tr>
                      
                      
                      
                        <th>
                            <?php echo e("Registrar"); ?>

                        </th>
                      
                      
                                         
                        <th>
                            <?php echo e("Class Name"); ?>

                        </th>
                      
                         
                    </tr>
                  
                </thead>
                <tbody>
              
                
                <?php $__currentLoopData = $assignclasses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $assignclass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <tr data-entry-id="">
                           
                          
                         
                          
                            <td>
                            <?php echo e($assignclass->registrar->name); ?>

                            </td>
                            <td>
                            <?php echo e($assignclass->class->name); ?>

                            </td>
                         
                           

                        </tr>
                      
                    
                          
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                   
                </tbody>
            </table>
           
        </div>
    </div>
</div>

                
                   <!--<h5>My Total Allowance</h5>
                   <div id="chart" style="height: 300px;"></div>-->
                   <?php else: ?>
                   <?php endif; ?>

               
                 </div>

             </div>

        </div>
    </div>
</div>
<script src="https://unpkg.com/chart.js@^2.9.3/dist/Chart.min.js"></script>
<!-- Chartisan -->
<script src="https://unpkg.com/@chartisan/chartjs@^2.1.0/dist/chartisan_chartjs.umd.js"></script>
 <!-- Charting library -->
 
    <script>
      const chart = new Chartisan({
        el: '#chart',
        url: "<?php echo route('charts.'.'sample_chart'); ?>",
        hooks: new ChartisanHooks()
             .colors()
             .responsive()
             .beginAtZero()
             .legend({ position: 'bottom' })
            // .title('This is a sample chart using chartisan!')
            //.datasets([{ type: 'line', fill: false }, 'bar']),
             //.datasets([{type:'line',fill:false, borderColor:'green'},'bar'])
      });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/azizizaidi/apps_2/resources/views/home.blade.php ENDPATH**/ ?>