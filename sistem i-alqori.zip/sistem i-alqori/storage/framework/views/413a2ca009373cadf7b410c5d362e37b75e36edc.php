<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.reportClass.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.report-classes.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            
              <div class="form-group">
                <label class="required" for="registrar_id"><?php echo e(trans('cruds.reportClass.fields.registrar')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('registrar') ? 'is-invalid' : ''); ?>" name="registrar_id" id="registrar_id" required>
              
                <?php $__currentLoopData = $registrars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $registrar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($id); ?>" ><?php echo e($registrar); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('registrar')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('registrar')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.reportClass.fields.registrar_helper')); ?></span>
            </div>

          
           
            <div class="form-group">
                <label class="required" for="class_names_id"><?php echo e(trans('cruds.reportClass.fields.classname')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('classname') ? 'is-invalid' : ''); ?>" name="class_names_id" id="class_names_id" required>
               
                <?php $__currentLoopData = $classnames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $classname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($id); ?>" ><?php echo e($classname); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('classname')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('classname')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.reportClass.fields.classname_helper')); ?></span>
            </div>
        
           
            <div class="form-group">
                <label class="required" for="date"><?php echo e(trans('cruds.reportClass.fields.date')); ?></label>
                <input class="form-control <?php echo e($errors->has('date') ? 'is-invalid' : ''); ?>" type="text" name="date" id="date" value="<?php echo e(old('date', '')); ?>" required>
                <?php if($errors->has('date')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('date')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.reportClass.fields.date_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="total_hour"><?php echo e(trans('cruds.reportClass.fields.total_hour')); ?></label>
                <input class="form-control <?php echo e($errors->has('total_hour') ? 'is-invalid' : ''); ?>" type="number" name="total_hour" id="total_hour" value="<?php echo e(old('total_hour', '')); ?>" step="1" required>
                <?php if($errors->has('total_hour')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('total_hour')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.reportClass.fields.total_hour_helper')); ?></span>
            </div>

             
           
            <div class="form-group">
                <label class="" for="class_names_id_2"><?php echo e(trans('cruds.reportClass.fields.classname_2')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('classname_2') ? 'is-invalid' : ''); ?>" name="class_names_id_2" id="class_names_id_2" >
               
                <?php $__currentLoopData = $classnames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $classname_2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($id); ?>" ><?php echo e($classname_2); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('classname_2')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('classname_2')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.reportClass.fields.classname_2_helper')); ?></span>
            </div>
        
           
            <div class="form-group">
                <label class="" for="date_2"><?php echo e(trans('cruds.reportClass.fields.date_2')); ?></label>
                <input class="form-control <?php echo e($errors->has('date_2') ? 'is-invalid' : ''); ?>" type="text" name="date_2" id="date_2" value="<?php echo e(old('date_2', '')); ?>" >
                <?php if($errors->has('date_2')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('date_2')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.reportClass.fields.date_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="" for="total_hour_2"><?php echo e(trans('cruds.reportClass.fields.total_hour_2')); ?></label>
                <input class="form-control <?php echo e($errors->has('total_hour_2') ? 'is-invalid' : ''); ?>" type="number" name="total_hour_2" id="total_hour_2" value="<?php echo e(old('total_hour_2', '')); ?>" step="1" >
                <?php if($errors->has('total_hour_2')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('total_hour_2')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.reportClass.fields.total_hour_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/azizizaidi/test/resources/views/admin/reportClasses/create.blade.php ENDPATH**/ ?>