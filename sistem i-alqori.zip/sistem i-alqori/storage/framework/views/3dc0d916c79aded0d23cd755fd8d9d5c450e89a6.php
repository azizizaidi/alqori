<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.invoice.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.invoices.update", [$invoice->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="student"><?php echo e(trans('cruds.invoice.fields.student')); ?></label>
                <input class="form-control <?php echo e($errors->has('student') ? 'is-invalid' : ''); ?>" type="text" name="student" id="student" value="<?php echo e(old('student', $invoice->student)); ?>">
                <?php if($errors->has('student')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('student')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.invoice.fields.student_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="registrar"><?php echo e(trans('cruds.invoice.fields.registrar')); ?></label>
                <input class="form-control <?php echo e($errors->has('registrar') ? 'is-invalid' : ''); ?>" type="text" name="registrar" id="registrar" value="<?php echo e(old('registrar', $invoice->registrar)); ?>">
                <?php if($errors->has('registrar')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('registrar')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.invoice.fields.registrar_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="teacher"><?php echo e(trans('cruds.invoice.fields.teacher')); ?></label>
                <input class="form-control <?php echo e($errors->has('teacher') ? 'is-invalid' : ''); ?>" type="text" name="teacher" id="teacher" value="<?php echo e(old('teacher', $invoice->teacher)); ?>">
                <?php if($errors->has('teacher')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('teacher')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.invoice.fields.teacher_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="class"><?php echo e(trans('cruds.invoice.fields.class')); ?></label>
                <input class="form-control <?php echo e($errors->has('class') ? 'is-invalid' : ''); ?>" type="text" name="class" id="class" value="<?php echo e(old('class', $invoice->class)); ?>">
                <?php if($errors->has('class')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('class')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.invoice.fields.class_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="total_hour"><?php echo e(trans('cruds.invoice.fields.total_hour')); ?></label>
                <input class="form-control <?php echo e($errors->has('total_hour') ? 'is-invalid' : ''); ?>" type="text" name="total_hour" id="total_hour" value="<?php echo e(old('total_hour', $invoice->total_hour)); ?>">
                <?php if($errors->has('total_hour')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('total_hour')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.invoice.fields.total_hour_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="amount_fee"><?php echo e(trans('cruds.invoice.fields.amount_fee')); ?></label>
                <input class="form-control <?php echo e($errors->has('amount_fee') ? 'is-invalid' : ''); ?>" type="text" name="amount_fee" id="amount_fee" value="<?php echo e(old('amount_fee', $invoice->amount_fee)); ?>">
                <?php if($errors->has('amount_fee')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('amount_fee')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.invoice.fields.amount_fee_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="date_class"><?php echo e(trans('cruds.invoice.fields.date_class')); ?></label>
                <input class="form-control <?php echo e($errors->has('date_class') ? 'is-invalid' : ''); ?>" type="text" name="date_class" id="date_class" value="<?php echo e(old('date_class', $invoice->date_class)); ?>">
                <?php if($errors->has('date_class')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('date_class')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.invoice.fields.date_class_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="fee_perhour"><?php echo e(trans('cruds.invoice.fields.fee_perhour')); ?></label>
                <input class="form-control <?php echo e($errors->has('fee_perhour') ? 'is-invalid' : ''); ?>" type="text" name="fee_perhour" id="fee_perhour" value="<?php echo e(old('fee_perhour', $invoice->fee_perhour)); ?>">
                <?php if($errors->has('fee_perhour')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('fee_perhour')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.invoice.fields.fee_perhour_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\school11\resources\views/admin/invoices/edit.blade.php ENDPATH**/ ?>