<?php

return [
    'failed'   => 'ID pengguna atau password salah',
    'password' => 'Password yang anda masukkan salah',
    'throttle' => 'Terlalu banyak percobaan log masuk.  Sila coba semula dalam :seconds saat.',
];
