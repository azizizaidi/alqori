<?php

return [
    'site_title' => 'i-ALQORI',
];
